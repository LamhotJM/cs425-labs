package edu.miu.cs.cs425.hackathon1srm4gdm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hackathon1Srm4gdmApplicationTests {

    @Test
    void contextLoads() {
    }

}
